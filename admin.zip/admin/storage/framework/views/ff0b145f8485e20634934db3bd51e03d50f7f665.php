
<?php $__env->startSection('judul','Sistem Penilaian'); ?>
<?php $__env->startSection('konten'); ?>

<div class="container col-md-8" style="margin-top:30px; margin-bottom:30px">
    <h4>
        SISTEM PENILAIAN
    </h4>
    <br>
    <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Judul Proposal</th>
            <th scope="col">Provinsi</th>
            <th scope="col">Kota/Kabupaten</th>
            <th scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Rancangan Alat atau Mesin Daur Ulang Sampah Terhadap Komunitas Bank Sampah (Bank Sampah Hijau Lestari Kiaracondong)</td>
            <td>Jawa Barat</td>
            <td>Kota Bandung</td>
          <td><a href="<?php echo e(url('/nilai')); ?>">Nilai</a></td>
          </tr>
        </tbody>
      </table>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Innov\resources\views/dosen.blade.php ENDPATH**/ ?>