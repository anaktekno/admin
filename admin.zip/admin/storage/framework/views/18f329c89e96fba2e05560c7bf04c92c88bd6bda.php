
<?php $__env->startSection('konten'); ?>
  <form class="form-signin" method="POST" action="<?php echo e(route('regiz')); ?>">
    <?php echo csrf_field(); ?>
    <h1 class="h3 mb-3 font-weight-normal">INNOVILLAGE</h1>
    <label for="inputName" class="sr-only">Nama</label>
    <input type="text" name="name" id="inputName" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" placeholder="Please insert your name" value="<?php echo e(old('name')); ?>" required autofocus>
    <br>
    <label for="inputEmail" class="sr-only">Email</label>
    <input type="email" name="email" id="inputEmail" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" placeholder="Email address" value="<?php echo e(old('email')); ?>">
    <br>
    <label for="inputPassword" class="sr-only">Password</label>
    <input type="password" name="password" id="inputPassword" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" placeholder="Password" required>
    <label for="inputPassword" class="sr-only">Password Confirmation</label>
    <input type="password" name="password_confirmation" id="inputPassword" class="form-control <?php echo e($errors->has('password_confirmation') ? 'is-invalid' : ''); ?>" placeholder="Password Confirmation" required>
    <br>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Register</button>
    <p class="mt-5 mb-3 text-muted">&copy; Innovillage 2020</p>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.log', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Innov\resources\views/regiz.blade.php ENDPATH**/ ?>