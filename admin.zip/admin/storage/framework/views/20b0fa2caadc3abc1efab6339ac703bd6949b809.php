
<?php $__env->startSection('judul','Sistem Input Penilaian'); ?>
<?php $__env->startSection('konten'); ?>

<div class="col-md-12">
    <div class="card">

<div class="container col-md-10" style="margin-top:30px; margin-bottom:30px">
    <h4>
        SISTEM INPUT PENILAIAN
    </h4>
    <table class="table table-borderless">
        <tbody>
            <tr>
                <td>
                    Judul
                </td>
                <td>: Rancangan Alat atau Mesin Daur Ulang Sampah Terhadap Komunitas Bank Sampah (Bank Sampah Hijau Lestari Kiaracondong)</td>
            </tr>
            <tr>
                <td>Provinsi</td>
                <td>: Jawa Barat</td>
            </tr><tr>
                <td>Kota/Kabupaten</td>
                <td>: Kota Bandung</td>
            </tr>
        </tbody>
    </table>
    <button type="button" class="btn btn-danger">File Proposal</button>
    <button type="button" class="btn btn-warning">URL Video</button>
    <br><br>
    <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col" style="width: 5%">#</th>
            <th scope="col" style="width: 55%">Poin Penilaian</th>
            <th scope="col" style="width: 40%">Nilai</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td><b>Orisinalitas Ide atau Gagasan</b><br>Original - Bersifat baru dan melibatkan teknologi digital<br>Identifiable - Identifikasi masalah jelas dan solusi berkaitan</td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="orisinalitas" id="ori1" value="option1">
                    <label class="form-check-label" for="inlineRadio1">1</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="orisinalitas" id="ori2" value="option2">
                    <label class="form-check-label" for="inlineRadio2">2</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="orisinalitas" id="ori3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">3</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="orisinalitas" id="ori4" value="option3" disabled>
                    <label class="form-check-label" for="inlineRadio3">4</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="orisinalitas" id="ori5" value="option3">
                    <label class="form-check-label" for="inlineRadio3">5</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="orisinalitas" id="ori6" value="option3">
                    <label class="form-check-label" for="inlineRadio3">6</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="orisinalitas" id="ori7" value="option3">
                    <label class="form-check-label" for="inlineRadio3">7</label>
                </div>
            </td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td><b>Inovasi Project Sosial</b><br>Applicable - Masuk akal dan dapat diterapkan<br>Publishable - Memiliki potensi untuk dipublikasikan</td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inovasi" id="inlineRadio1" value="option1">
                    <label class="form-check-label" for="inlineRadio1">1</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inovasi" id="inlineRadio2" value="option2">
                    <label class="form-check-label" for="inlineRadio2">2</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inovasi" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">3</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inovasi" id="inlineRadio3" value="option3" disabled>
                    <label class="form-check-label" for="inlineRadio3">4</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inovasi" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">5</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inovasi" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">6</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inovasi" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">7</label>
                </div>
            </td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td><b>Kolaborasi</b><br>Cooperation - Solusi antardisiplin ilmu dalam tim<br>Coordination - Memiliki pembagian jobdesc sesuai dengan bidang ilmu anggota tim</td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="kolaborasi" id="inlineRadio1" value="option1">
                    <label class="form-check-label" for="inlineRadio1">1</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="kolaborasi" id="inlineRadio2" value="option2">
                    <label class="form-check-label" for="inlineRadio2">2</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="kolaborasi" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">3</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="kolaborasi" id="inlineRadio3" value="option3" disabled>
                    <label class="form-check-label" for="inlineRadio3">4</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="kolaborasi" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">5</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="kolaborasi" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">6</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="kolaborasi" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">7</label>
                </div>
            </td>
          </tr>
          <tr>
            <th scope="row">4</th>
            <td><b>Kebermanfaatan</b><br>Maintainable - Solusi dapat dipergunakan dan dioperasikan<br>Synergy - Melibatkan peran serta masyarakat desa sasar</td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maintenance" id="inlineRadio1" value="option1">
                    <label class="form-check-label" for="inlineRadio1">1</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maintenance" id="inlineRadio2" value="option2">
                    <label class="form-check-label" for="inlineRadio2">2</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maintenance" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">3</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maintenance" id="inlineRadio3" value="option3" disabled>
                    <label class="form-check-label" for="inlineRadio3">4</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maintenance" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">5</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maintenance" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">6</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="maintenance" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">7</label>
                </div>
            </td>
          </tr>
          <tr>
            <th scope="row">5</th>
            <td><b>Sustainability</b><br>Designed - Memiliki Roadmap<br>Expandable - Solusi berpotensi untuk dapat ditingkatkan dalam rangka mencapai target kebermanfaatan dan impact yang lebih besar</td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="sustainability" id="inlineRadio1" value="option1">
                    <label class="form-check-label" for="inlineRadio1">1</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="sustainability" id="inlineRadio2" value="option2">
                    <label class="form-check-label" for="inlineRadio2">2</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="sustainability" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">3</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="sustainability" id="inlineRadio3" value="option3" disabled>
                    <label class="form-check-label" for="inlineRadio3">4</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="sustainability" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">5</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="sustainability" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">6</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="sustainability" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">7</label>
                </div>
            </td>
          </tr>
          <tr>
            <th scope="row">6</th>
            <td><b>Tata Kata dan Penulisan</b><br>Clarity - Alur penjelasan yang jelas dan mudah dipahami, serta mengikuti kaidah kebahasaan</td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tatatulis" id="inlineRadio1" value="option1">
                    <label class="form-check-label" for="inlineRadio1">1</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tatatulis" id="inlineRadio2" value="option2">
                    <label class="form-check-label" for="inlineRadio2">2</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tatatulis" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">3</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tatatulis" id="inlineRadio3" value="option3" disabled>
                    <label class="form-check-label" for="inlineRadio3">4</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tatatulis" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">5</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tatatulis" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">6</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tatatulis" id="inlineRadio3" value="option3">
                    <label class="form-check-label" for="inlineRadio3">7</label>
                </div>
            </td>
          </tr>
          <tr>
            <th scope="row">7</th>
            <td><b>Video</b></td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="video" id="inlineRadio1" value="option1">
                    <label class="form-check-label" for="inlineRadio1">Ya</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="video" id="inlineRadio2" value="option2">
                    <label class="form-check-label" for="inlineRadio2">Tidak</label>
                </div>
            </td>
          </tr>
        </tbody>
      </table>

      <button type="button" class="btn btn-primary float-right">Submit Nilai</button>
      <br><br>
</div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Innov\resources\views/nilai.blade.php ENDPATH**/ ?>