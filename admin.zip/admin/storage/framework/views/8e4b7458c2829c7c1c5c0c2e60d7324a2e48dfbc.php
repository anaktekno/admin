
<?php $__env->startSection('judul','Data Semua Proposal'); ?>
<?php $__env->startSection('konten'); ?>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Selamat Datang <?php echo e(\Auth::user()->name); ?>!</strong>
                    </div>

                    <div class="card-body">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success  mb-2"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <?php if(session('danger')): ?>
                        <div class="alert alert-danger  mb-2"><?php echo e(session('danger')); ?></div>
                        <?php endif; ?>

                        <div class="my-2">
                            <button type="button" class="btn btn-danger m-l-10 m-b-10">Belum dinilai <span id="belum"
                                    class="badge badge-light"></span></button>
                            <button type="button" class="btn btn-success m-l-10 m-b-10">Sudah dinilai <span id="sudah"
                                    class="badge badge-light"></span></button>
                            <button type="button" class="btn btn-primary m-l-10 m-b-10">Total proposal <span id="sudah"
                                    class="badge badge-light"><?php echo e(count($proposal)); ?></span></button>
                        </div>


                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Institusi</th>
                                    <th>Judul Proposal</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $proposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop -> iteration); ?></td>
                                    <td><?php echo e($item -> Institusi_Anggota_1); ?></td>
                                    
                                    <td><?php echo e($item -> Judul_Proposal); ?></td>

                                    <td>
                                        <?php if(count($item->nilai) == 2): ?>
                                        <div class="badge sudah p-2 badge-success">Sudah dinilai</div>
                                        <?php else: ?>
                                        <div class="badge belum p-2 badge-danger">Belum dinilai</div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('style/vendors/jquery/dist/jquery.min.js')); ?>"></script>
<script>
    let belum = $('.belum').length;
        let sudah = $('.sudah').length;
        $('#belum').html(belum)
        $('#sudah').html(sudah)
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GFR\Desktop\11-11\admin\resources\views/all.blade.php ENDPATH**/ ?>