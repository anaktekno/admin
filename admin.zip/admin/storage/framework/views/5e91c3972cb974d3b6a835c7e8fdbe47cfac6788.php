
<?php $__env->startSection('judul','Data Proposal'); ?>
<?php $__env->startSection('konten'); ?>

<div class="content mt-3">
    <div class="card">
        <div class="card-header">
            <h2>
                <?php echo e($proposal->Judul_Proposal); ?>

            </h2>
            <small><?php echo e($proposal->Date); ?></small>
        </div>

        <div class="card-body">
            <a class="btn my-2 col-sm-2 btn-danger" href="<?php echo e($proposal->File_Proposal); ?>"> <i
                    class="menu-icon fa fa-download"></i>
                File Proposal</a>
            <a class="btn my-2 col-sm-2 text-white btn-warning" href="<?php echo e($proposal->Youtubeurl); ?>"> <i
                    class="menu-icon fa fa-desktop"></i>
                Video Proposal</a>
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th scope="col" style="width: 20%">Reviewer 1</th>
                        <th scope="col"><?php echo e($proposal->nilai[0]->user->name); ?></th>
                    </tr>
                    <tr>
                        <th scope="col" style="width: 20%">Reviewer 2</th>
                        <th scope="col"><?php echo e($proposal->nilai[1]->user->name ?? '-'); ?></th>
                    </tr>
                    <tr>
                        <th scope="col" style="width: 20%">Judul Proposal</th>
                        <th scope="col"><?php echo e($proposal -> Judul_Proposal); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">Provinsi</th>
                        <td><?php echo e($proposal -> Provinsi); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Kota/ Kabupaten</th>
                        <td><?php echo e($proposal -> Kota_Kabupaten); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Nama Ketua</th>
                        <td><?php echo e($proposal -> Nama_Anggota_1_Ketua); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">NIM Ketua</th>
                        <td><?php echo e($proposal -> NIM_Anggota_1); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Institusi Ketua</th>
                        <td><?php echo e($proposal -> Institusi_Anggota_1); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Fakultas Ketua</th>
                        <td><?php echo e($proposal -> Fakultas_Anggota_1); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Program Studi Ketua</th>
                        <td><?php echo e($proposal -> Program_Studi_Anggota_1); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Nama Ketua</th>
                        <td><?php echo e($proposal -> Nama_Anggota_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">NIM Ketua</th>
                        <td><?php echo e($proposal -> NIM_Anggota_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Institusi Ketua</th>
                        <td><?php echo e($proposal -> Institusi_Anggota_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Fakultas Ketua</th>
                        <td><?php echo e($proposal -> Fakultas_Anggota_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Program Studi Ketua</th>
                        <td><?php echo e($proposal -> Program_Studi); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Nama Ketua</th>
                        <td><?php echo e($proposal -> Nama_Anggota_3); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">NIM Ketua</th>
                        <td><?php echo e($proposal -> NIM_Anggota_3); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Institusi Ketua</th>
                        <td><?php echo e($proposal -> Institusi_Anggota_3); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Fakultas Ketua</th>
                        <td><?php echo e($proposal -> Fakultas_Anggota_3); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Program Studi Ketua</th>
                        <td><?php echo e($proposal -> Program_Studi_Anggota_3); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">No Telp Ketua</th>
                        <td><?php echo e($proposal -> Nomor_Telp_Ketua); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Alamat Email Ketua</th>
                        <td><?php echo e($proposal -> Alamat_Email); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Dosen Pembimbing</th>
                        <td><?php echo e($proposal -> Nama_Dosen); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">NRP Dosen</th>
                        <td><?php echo e($proposal -> Nip_Dosen); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">No Telp Dosen</th>
                        <td><?php echo e($proposal -> Nomor_Telp_Dosen); ?></td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Innov\resources\views/proposal.blade.php ENDPATH**/ ?>