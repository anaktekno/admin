<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Innovillage</title>

    <link rel="canonical" href="<?php echo e(url('https://getbootstrap.com/docs/4.0/examples/sign-in/')); ?>">

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('https://getbootstrap.com/docs/4.0/examples/sign-in/signin.css')); ?>" rel="stylesheet">
  </head>

  <body class="text-center">
  <form class="form-signin" method="POST" action="<?php echo e(route('regiz')); ?>">
    <?php echo csrf_field(); ?>
    <h1 class="h3 mb-3 font-weight-normal">INNOVILLAGE</h1>
    <label for="inputName" class="sr-only">Nama</label>
    <input type="text" name="name" id="inputName" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" placeholder="Please insert your name" value="<?php echo e(old('name')); ?>" required autofocus>
    <br>
    <label for="inputEmail" class="sr-only">Email</label>
    <input type="email" name="email" id="inputEmail" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" placeholder="Email address" value="<?php echo e(old('email')); ?>">
    <br>
    <label for="inputPassword" class="sr-only">Password</label>
    <input type="password" name="password" id="inputPassword" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" placeholder="Password" required>
    <label for="inputPassword" class="sr-only">Password Confirmation</label>
    <input type="password" name="password_confirmation" id="inputPassword" class="form-control <?php echo e($errors->has('password_confirmation') ? 'is-invalid' : ''); ?>" placeholder="Password Confirmation" required>
    <br>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Register</button>
    <p class="mt-5 mb-3 text-muted">&copy; Innovillage 2020</p>
  </form>
</body>
</html><?php /**PATH E:\projects\Innov\resources\views/regiz.blade.php ENDPATH**/ ?>