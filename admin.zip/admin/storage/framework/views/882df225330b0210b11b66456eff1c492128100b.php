<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Innovillage</title>

    <link rel="canonical" href="<?php echo e(url('https://getbootstrap.com/docs/4.0/examples/sign-in/')); ?>">

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('https://getbootstrap.com/docs/4.0/examples/sign-in/signin.css')); ?>" rel="stylesheet">
  </head>

  <body class="text-center">
    <?php echo $__env->yieldContent('konten'); ?>
</body>
</html><?php /**PATH E:\xampp\htdocs\Innov\resources\views/layouts/log.blade.php ENDPATH**/ ?>