
<?php $__env->startSection('judul','Data Penilaian'); ?>
<?php $__env->startSection('konten'); ?>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Penilaian</strong>
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success  mb-2"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <?php if(session('danger')): ?>
                        <div class="alert alert-danger  mb-2"><?php echo e(session('danger')); ?></div>
                        <?php endif; ?>

                        <table id="bootstrap-data-table-export" class="table table-sms table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th rowspan="3">No</th>
                                    
                                    <th rowspan="3" style="width: 50%">Judul</th>
                                    <th rowspan="3">Data Lengkap</th>
                                    <th rowspan="1" class="text-center" colspan="6">Hasil Assesment</th>
                                    <th class="text-center" rowspan="1" colspan="3">Hasil Ahkir</th>
                                </tr>
                                <tr>
                                    <th rowspan="1" class="text-center" colspan="3">Nilai</th>
                                    <th rowspan="1" class="text-center" colspan="2">Rekomendasi Anggaran</th>
                                    <th rowspan="2">CATATAN</th>
                                    <th rowspan="1" colspan="2"></th>
                                </tr>
                                <tr>
                                    <th>Reviewer 1</th>
                                    <th>Reviewer 2</th>
                                    <th>Nilai Total</th>
                                    <th>Reviewer 1</th>
                                    <th>Reviewer 2</th>
                                    <th>Hasil</th>
                                    <th>Status</th>

                                </tr>





                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->iteration); ?></th>
                                    
                                    <th><?php echo e($item[0]->proposal->Judul_Proposal); ?></th>
                                    <th>
                                        <a class="badge badge-success"
                                            href="<?php echo e(route('proposal',$item[0]->proposal->Id)); ?>">
                                            Detail
                                        </a>
                                    </th>
                                    <th><?php echo e($item[0]->total); ?></th>
                                    <th>
                                        <?php if(count($item) > 1): ?>
                                        <?php echo e($item[1]->total); ?>

                                        <?php else: ?>
                                        -
                                        <?php endif; ?>
                                    </th>
                                    <th>
                                        <?php if(count($item) > 1): ?>
                                        <?php echo e(($item[0]->total + $item[1]->total) / 2); ?>

                                        <?php else: ?>
                                        <?php echo e($item[0]->total / 2); ?>

                                        <?php endif; ?>
                                    </th>
                                    <th><?php echo e($item[0]->anggaran); ?></th>
                                    <th><?php echo e($item[1]->anggaran ?? '-'); ?></th>
                                    <th>

                                        <button data-toggle="modal" data-target="#exampleModal"
                                            data-catatan1="<?php echo e($item[0]->komentar); ?>"
                                            data-catatan2="<?php echo e($item[1]->komentar ?? '-'); ?>"
                                            class="btn catatan badge badge-warning">Detail</button>
                                    </th>
                                    <th>
                                        <form action="<?php echo e(route('acc', $item[0]->proposal->Id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="value" value="1">
                                            <button class="btn badge text-white badge-success">Setuju</button>
                                        </form>

                                        <form action="<?php echo e(route('acc', $item[0]->proposal->Id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="value" value="0">
                                            <button class="btn badge text-white badge-danger">Tidak Setuju</button>
                                        </form>
                                    </th>
                                    <th>
                                        <?php if($item[0]->proposal->Setuju == 1): ?>
                                        <div class="badge p-3 badge-success">Disetujui</div>
                                        <?php elseif($item[0]->proposal->Setuju === 0): ?>
                                        <div class="badge p-3 badge-danger">Tidak Disetujui</div>
                                        <?php else: ?>
                                        -
                                        <?php endif; ?>

                                    </th>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">CATATAN</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-header">
                        Catatan 1
                    </div>
                    <div id="komentar1" class="card-body">

                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        Catatan 2
                    </div>
                    <div id="komentar2" class="card-body">

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('style/vendors/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script>
    $('.catatan').on('click',function(){
        $('#komentar1').html($(this).data('catatan1'))
        $('#komentar2').html($(this).data('catatan2'))

    })

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\GFR\Desktop\New folder\Innov Final\Innov\resources\views/nilai.blade.php ENDPATH**/ ?>