
<?php $__env->startSection('judul','Data Pendaftaran'); ?>
<?php $__env->startSection('konten'); ?>

<div class="content mt-3">
  <div class="animated fadeIn">
      <div class="row">

          <div class="col-md-12">
              <div class="card">
                  <div class="card-header">
                  <strong class="card-title">Selamat Datang <?php echo e(\Auth::user()->name); ?>!</strong>
                  </div>
                  <div class="card-body">
                      <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                          <thead>
                              <tr>
                                  <th>No</th>
                                  <th>Institusi</th>
                                  
                                  <th>Judul Proposal</th>
                                  <th>Provinsi</th>
                                  <th>Kabupaten</th>
                                  <th>Penilaian</th>
                                  <th>Status</th>
                              </tr>
                            </thead>
                          <tbody>
                              <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($loop -> iteration); ?></td>
                                  <td><?php echo e($item -> Institusi_Anggota_1); ?></td>
                                  
                                  <td><?php echo e($item -> Judul_Proposal); ?></td>
                                  <td><?php echo e($item -> Provinsi); ?></td>
                                  <td><?php echo e($item -> Kota_Kabupaten); ?></td>
                                  <td><a href="<?php echo e(url('/detil/' .$item -> Id)); ?>" class="btn btn-warning active" role="button" aria-pressed="true">Penilaian</a></td>
                                  <td></td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>


      </div>
  </div><!-- .animated -->
</div><!-- .content -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Innov\resources\views/dashboard.blade.php ENDPATH**/ ?>