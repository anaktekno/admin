
<?php $__env->startSection('judul','Data Proposal'); ?>
<?php $__env->startSection('konten'); ?>

<div class="content mt-3">
    <div class="card">
        <div class="card-header">
            <h2>
                <?php echo e($proposal->Judul_Proposal); ?>

            </h2>
        </div>

        <div class="card-body">   
            <a class="btn my-2 col-sm-2 text-white btn-dark"> <i
                class="menu-icon fa fa-file-text"></i>
                Nilai Total: <?php echo e(($proposal->nilai[0]->original+
                    $proposal->nilai[0]->inovasi+
                    $proposal->nilai[0]->kolaborasi+
                    $proposal->nilai[0]->kebermanfaatan+
                    $proposal->nilai[0]->sustainability+
                    $proposal->nilai[0]->TTKI +
                    $proposal->nilai[1]->original +
                    $proposal->nilai[1]->inovasi +
                    $proposal->nilai[1]->kolaborasi +
                    $proposal->nilai[1]->kebermanfaatan +
                    $proposal->nilai[1]->sustainability +
                    $proposal->nilai[1]->TTKI)/2); ?></a>
            <a class="btn my-2 col-sm-2 btn-danger" href="<?php echo e($proposal->File_Proposal); ?>" target="_blank"> <i
                class="menu-icon fa fa-download"></i>
            File Proposal</a>
            <a class="btn my-2 col-sm-2 text-white btn-warning" href="<?php echo e($proposal->Youtubeurl); ?>" target="_blank"> <i
                class="menu-icon fa fa-desktop"></i>
            Video Proposal</a>
            <table class="table table-sm">
                <tbody>
                    <tr>
                        <th scope="col" style="width: 20%">Reviewer 1</th>
                        <th scope="col"><?php echo e($proposal->nilai[0]->user->name); ?></th>
                    </tr>
                    <tr>
                        <td scope="row">• Komentar</td>
                        <td><?php echo e($proposal->nilai[0]->komentar); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">• Rekomendasi Anggaran</td>
                        <td><?php echo e($proposal->nilai[0]->anggaran); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">• Nilai Detail</td>
                        <td>
                            Orisinalitas Ide: <b><?php echo e($proposal->nilai[0]->original); ?></b> | 
                            Inovasi: <b><?php echo e($proposal->nilai[0]->inovasi); ?></b> | 
                            Kolaborasi: <b><?php echo e($proposal->nilai[0]->kolaborasi); ?></b> |
                            Kebermanfaatan: <b><?php echo e($proposal->nilai[0]->kebermanfaatan); ?></b> |
                            Sustainability: <b><?php echo e($proposal->nilai[0]->sustainability); ?></b> |
                            Tata Kata dan Penulisan: <b><?php echo e($proposal->nilai[0]->TTKI); ?>

                        </td>                       
                    </tr>
                    <tr>
                        <td scope="row">• Nilai Reviewer 1</td>
                        <td>
                            <b><?php echo e($proposal->nilai[0]->original+
                            $proposal->nilai[0]->inovasi+
                            $proposal->nilai[0]->kolaborasi+
                            $proposal->nilai[0]->kebermanfaatan+
                            $proposal->nilai[0]->sustainability+
                            $proposal->nilai[0]->TTKI); ?></b>
                        </td>                       
                    </tr>
                    <tr>
                        <th scope="col" style="width: 20%">Reviewer 2</th>
                        <th scope="col"><?php echo e($proposal->nilai[1]->user->name ?? '-'); ?></th>
                    </tr>

                    <tr>
                        <td scope="row">• Komentar Reviewer</td>
                        <td><?php echo e($proposal->nilai[1]->komentar ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">• Rekomendasi Anggaran</td>
                        <td><?php echo e($proposal->nilai[1]->anggaran ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">• Nilai Reviewer 2</td>
                        <td>
                            Orisinalitas Ide: <b><?php echo e($proposal->nilai[1]->original ?? '-'); ?></b> | 
                            Inovasi: <b><?php echo e($proposal->nilai[1]->inovasi ?? '-'); ?></b> | 
                            Kolaborasi: <b><?php echo e($proposal->nilai[1]->kolaborasi ?? '-'); ?></b> |
                            Kebermanfaatan: <b><?php echo e($proposal->nilai[1]->kebermanfaatan ?? '-'); ?></b> |
                            Sustainability: <b><?php echo e($proposal->nilai[1]->sustainability ?? '-'); ?></b> |
                            Tata Kata dan Penulisan: <b><?php echo e($proposal->nilai[1]->TTKI ?? '-'); ?></b>
                        </td>                     
                    </tr>
                    <tr>
                        <td scope="row">• Nilai Total</td>
                        <td>
                            <b><?php echo e($proposal->nilai[1]->original +
                            $proposal->nilai[1]->inovasi +
                            $proposal->nilai[1]->kolaborasi +
                            $proposal->nilai[1]->kebermanfaatan +
                            $proposal->nilai[1]->sustainability +
                            $proposal->nilai[1]->TTKI); ?></b>
                        </td>                       
                    </tr>
                    <tr>
                        <th scope="col" style="width: 20%">Judul Proposal</th>
                        <th scope="col"><?php echo e($proposal -> Judul_Proposal); ?></th>
                    </tr>
                    <tr>
                        <td scope="row">Provinsi</td>
                        <td><?php echo e($proposal -> Provinsi); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Kota/ Kabupaten</td>
                        <td><?php echo e($proposal -> Kota_Kabupaten); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Nama Ketua</th>
                        <th><?php echo e($proposal -> Nama_Anggota_1_Ketua); ?></th>
                    </tr>
                    <tr>
                        <td scope="row">NIM Ketua</td>
                        <td><?php echo e($proposal -> NIM_Anggota_1); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Institusi Ketua</td>
                        <td><?php echo e($proposal -> Institusi_Anggota_1); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Fakultas Ketua</td>
                        <td><?php echo e($proposal -> Fakultas_Anggota_1); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Program Studi Ketua</td>
                        <td><?php echo e($proposal -> Program_Studi_Anggota_1); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Nama Anggota 1</th>
                        <th><?php echo e($proposal -> Nama_Anggota_2); ?></th>
                    </tr>
                    <tr>
                        <td scope="row">NIM Anggota 1</td>
                        <td><?php echo e($proposal -> NIM_Anggota_2); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Institusi Anggota 1</td>
                        <td><?php echo e($proposal -> Institusi_Anggota_2); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Fakultas Anggota 1</td>
                        <td><?php echo e($proposal -> Fakultas_Anggota_2); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Program Studi Anggota 1</td>
                        <td><?php echo e($proposal -> Program_Studi); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Nama Anggota 2</th>
                        <th><?php echo e($proposal -> Nama_Anggota_3); ?></th>
                    </tr>
                    <tr>
                        <td scope="row">NIM Anggota 2</td>
                        <td><?php echo e($proposal -> NIM_Anggota_3); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Institusi Anggota 2</td>
                        <td><?php echo e($proposal -> Institusi_Anggota_3); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Fakultas Anggota 2</td>
                        <td><?php echo e($proposal -> Fakultas_Anggota_3); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Program Studi Anggota 2</td>
                        <td><?php echo e($proposal -> Program_Studi_Anggota_3); ?></td>
                    </tr>

                    <tr>
                        <td scope="row">No Telp Ketua</td>
                        <td><?php echo e($proposal -> Nomor_Telp_Ketua); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Alamat Email Ketua</td>
                        <td><?php echo e($proposal -> Alamat_Email); ?></td>
                    </tr>

                    <tr>
                        <th scope="row">Dosen Pembimbing</th>
                        <th><?php echo e($proposal -> Nama_Dosen); ?></th>
                    </tr>
                    <tr>
                        <td scope="row">NRP Dosen</td>
                        <td><?php echo e($proposal -> Nip_Dosen); ?></td>
                    </tr>

                    <tr>
                        <td scope="row">No Telp Dosen</td>
                        <td><?php echo e($proposal -> Nomor_Telp_Dosen); ?></td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\innovillage baru\admin\resources\views/proposal.blade.php ENDPATH**/ ?>