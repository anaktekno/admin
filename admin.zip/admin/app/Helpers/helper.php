<?php

function total($total)
{
    return 'a';
}
